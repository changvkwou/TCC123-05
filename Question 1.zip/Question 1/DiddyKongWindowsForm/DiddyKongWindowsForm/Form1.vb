﻿Imports System.Data.Entity

Public Class Form1
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        db = New Assignment2Entities()
        db.DiddyKongs.Load()
        DiddyKongBindingSource.DataSource = db.DiddyKongs.Local

    End Sub

    Private db As Assignment2Entities

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        DiddyKongBindingSource.AddNew()
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        db.SaveChanges()
        MessageBox.Show("Record has been updated successfully")
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If MessageBox.Show("Are you sure want to delete this record", "Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
            DiddyKongBindingSource.RemoveCurrent()
            db.SaveChanges()
        End If
    End Sub
End Class

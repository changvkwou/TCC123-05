﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtTitleName = New System.Windows.Forms.TextBox()
        Me.txtReleaseYears = New System.Windows.Forms.TextBox()
        Me.txtReleaseMonth = New System.Windows.Forms.TextBox()
        Me.txtGamePlatforms = New System.Windows.Forms.TextBox()
        Me.txtDesigners = New System.Windows.Forms.TextBox()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.TitleNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ReleaseYearDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ReleaseMonthDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GamePlatformsDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DesignersDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DiddyKongBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Label = New System.Windows.Forms.Label()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DiddyKongBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.Label1.Location = New System.Drawing.Point(43, 48)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(71, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "*Title Name : "
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(43, 96)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(82, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Release Years :"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(43, 149)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(85, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Release Month :"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(43, 198)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(87, 13)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Game Platforms :"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(43, 247)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(60, 13)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Designers :"
        '
        'txtTitleName
        '
        Me.txtTitleName.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DiddyKongBindingSource, "Title_Name", True))
        Me.txtTitleName.Location = New System.Drawing.Point(46, 64)
        Me.txtTitleName.Name = "txtTitleName"
        Me.txtTitleName.Size = New System.Drawing.Size(559, 20)
        Me.txtTitleName.TabIndex = 5
        '
        'txtReleaseYears
        '
        Me.txtReleaseYears.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DiddyKongBindingSource, "Release_Year", True))
        Me.txtReleaseYears.Location = New System.Drawing.Point(46, 112)
        Me.txtReleaseYears.Name = "txtReleaseYears"
        Me.txtReleaseYears.Size = New System.Drawing.Size(559, 20)
        Me.txtReleaseYears.TabIndex = 6
        '
        'txtReleaseMonth
        '
        Me.txtReleaseMonth.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DiddyKongBindingSource, "Release_Month", True))
        Me.txtReleaseMonth.Location = New System.Drawing.Point(46, 165)
        Me.txtReleaseMonth.Name = "txtReleaseMonth"
        Me.txtReleaseMonth.Size = New System.Drawing.Size(559, 20)
        Me.txtReleaseMonth.TabIndex = 7
        '
        'txtGamePlatforms
        '
        Me.txtGamePlatforms.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DiddyKongBindingSource, "Game_Platforms", True))
        Me.txtGamePlatforms.Location = New System.Drawing.Point(46, 214)
        Me.txtGamePlatforms.Name = "txtGamePlatforms"
        Me.txtGamePlatforms.Size = New System.Drawing.Size(559, 20)
        Me.txtGamePlatforms.TabIndex = 8
        '
        'txtDesigners
        '
        Me.txtDesigners.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DiddyKongBindingSource, "Designers", True))
        Me.txtDesigners.Location = New System.Drawing.Point(46, 263)
        Me.txtDesigners.Name = "txtDesigners"
        Me.txtDesigners.Size = New System.Drawing.Size(559, 20)
        Me.txtDesigners.TabIndex = 9
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.TitleNameDataGridViewTextBoxColumn, Me.ReleaseYearDataGridViewTextBoxColumn, Me.ReleaseMonthDataGridViewTextBoxColumn, Me.GamePlatformsDataGridViewTextBoxColumn, Me.DesignersDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.DiddyKongBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(46, 351)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(794, 356)
        Me.DataGridView1.TabIndex = 10
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(368, 307)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(75, 23)
        Me.btnAdd.TabIndex = 11
        Me.btnAdd.Text = "Add"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'btnUpdate
        '
        Me.btnUpdate.Location = New System.Drawing.Point(449, 307)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(75, 23)
        Me.btnUpdate.TabIndex = 12
        Me.btnUpdate.Text = "Update"
        Me.btnUpdate.UseVisualStyleBackColor = True
        '
        'btnDelete
        '
        Me.btnDelete.Location = New System.Drawing.Point(530, 307)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(75, 23)
        Me.btnDelete.TabIndex = 13
        Me.btnDelete.Text = "Delete"
        Me.btnDelete.UseVisualStyleBackColor = True
        '
        'TitleNameDataGridViewTextBoxColumn
        '
        Me.TitleNameDataGridViewTextBoxColumn.DataPropertyName = "Title_Name"
        Me.TitleNameDataGridViewTextBoxColumn.HeaderText = "Title_Name"
        Me.TitleNameDataGridViewTextBoxColumn.Name = "TitleNameDataGridViewTextBoxColumn"
        '
        'ReleaseYearDataGridViewTextBoxColumn
        '
        Me.ReleaseYearDataGridViewTextBoxColumn.DataPropertyName = "Release_Year"
        Me.ReleaseYearDataGridViewTextBoxColumn.HeaderText = "Release_Year"
        Me.ReleaseYearDataGridViewTextBoxColumn.Name = "ReleaseYearDataGridViewTextBoxColumn"
        '
        'ReleaseMonthDataGridViewTextBoxColumn
        '
        Me.ReleaseMonthDataGridViewTextBoxColumn.DataPropertyName = "Release_Month"
        Me.ReleaseMonthDataGridViewTextBoxColumn.HeaderText = "Release_Month"
        Me.ReleaseMonthDataGridViewTextBoxColumn.Name = "ReleaseMonthDataGridViewTextBoxColumn"
        '
        'GamePlatformsDataGridViewTextBoxColumn
        '
        Me.GamePlatformsDataGridViewTextBoxColumn.DataPropertyName = "Game_Platforms"
        Me.GamePlatformsDataGridViewTextBoxColumn.HeaderText = "Game_Platforms"
        Me.GamePlatformsDataGridViewTextBoxColumn.Name = "GamePlatformsDataGridViewTextBoxColumn"
        '
        'DesignersDataGridViewTextBoxColumn
        '
        Me.DesignersDataGridViewTextBoxColumn.DataPropertyName = "Designers"
        Me.DesignersDataGridViewTextBoxColumn.HeaderText = "Designers"
        Me.DesignersDataGridViewTextBoxColumn.Name = "DesignersDataGridViewTextBoxColumn"
        '
        'DiddyKongBindingSource
        '
        Me.DiddyKongBindingSource.DataSource = GetType(DiddyKongWindowsForm.DiddyKong)
        '
        'Label
        '
        Me.Label.AutoSize = True
        Me.Label.Location = New System.Drawing.Point(43, 312)
        Me.Label.Name = "Label"
        Me.Label.Size = New System.Drawing.Size(193, 13)
        Me.Label.TabIndex = 14
        Me.Label.Text = "*Remark : Title Name not allow to EDIT"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1291, 1095)
        Me.Controls.Add(Me.Label)
        Me.Controls.Add(Me.btnDelete)
        Me.Controls.Add(Me.btnUpdate)
        Me.Controls.Add(Me.btnAdd)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.txtDesigners)
        Me.Controls.Add(Me.txtGamePlatforms)
        Me.Controls.Add(Me.txtReleaseMonth)
        Me.Controls.Add(Me.txtReleaseYears)
        Me.Controls.Add(Me.txtTitleName)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Diddy Kong"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DiddyKongBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents txtTitleName As TextBox
    Friend WithEvents txtReleaseYears As TextBox
    Friend WithEvents txtReleaseMonth As TextBox
    Friend WithEvents txtGamePlatforms As TextBox
    Friend WithEvents txtDesigners As TextBox
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents TitleNameDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ReleaseYearDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ReleaseMonthDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents GamePlatformsDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DesignersDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DiddyKongBindingSource As BindingSource
    Friend WithEvents btnAdd As Button
    Friend WithEvents btnUpdate As Button
    Friend WithEvents btnDelete As Button
    Friend WithEvents Label As Label
End Class
